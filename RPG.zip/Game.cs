﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Core;
using RPG;
public class Game : MonoBehaviour {

    static StateMachine Machine;
	// Use this for initialization
	void Start ()
    {
        //GameObject uiLoadObj=WindowManager.GetManager().OpenWindow("UILoad");
        //uiJIngdu uiload = uiLoadObj.GetComponent<uiJIngdu>();
        //LoadSceneManager.Load("City", uiload);

        //WindowManager.GetManager().OpenWindow("UILoad", (uiObj) => 
        //{
        //    if (uiObj!=null)
        //    {
        //        UILoading uiload = uiObj.GetComponent<UILoading>();
        //        LoadSceneManager.Load("City", uiload);
        //    }
        //});
        //return;
        DontDestroyOnLoad(this.gameObject);//让某个物体在跳转场景时不被销毁

        Machine = new StateMachine();
        Machine.AddState(new LoginScene());
        Machine.AddState(new GameScene());
        Machine.AddState(new OverScene());
        Goto(SceneType.Login);
       
    }
   
    public static void Goto(SceneType sceneType)
    {
        if (Machine!=null)
        {
            Machine.GoTo(sceneType.ToString());
        }
    }
	// Update is called once per frame
	void Update ()
    {
        if (Machine!=null)
        {
            Machine.OnUpdate();//状态机更新
        }
        if (Input.GetKeyDown(KeyCode.Z))
        {
           Goto(SceneType.Login);
        }
        if (Input.GetKeyDown(KeyCode.X))
        {
            Goto(SceneType.Game);
        }
        if (Input.GetKeyDown(KeyCode.C))
        {
            Goto(SceneType.Over);
        }
       
    }
    void OnDestroy()
    {
        NetworkManager.Close();
    }
}
