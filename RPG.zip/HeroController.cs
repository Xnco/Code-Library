﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Core;

//主角控制器
public class HeroController : MonoBehaviour
{
    public RoleController mRoleController;//角色控制器
    private bool FistDrag=true;
    private void Start()
    {
        if (mRoleController==null)
        {
            mRoleController = GetComponentInChildren<RoleController>();
        }
        UIJoystick.onStart = (vec3) =>
        {
                FistDrag=true;
            //SendCommand(RoleCommand.Run);
        };
        UIJoystick.onDrag = (vec3) =>
        {
           // mRoleController.ExcuteCommand(RoleCommand.Run);
            Vector3 dir = new Vector3(vec3.x,0,vec3.y);
            if (FistDrag||Vector3.Angle(this.transform.forward,dir)>10) 
            {
                FistDrag=false;
                mRoleController.Turn(dir);
                SendCommand(RoleCommand.Run);
            }
            
        };
        UIJoystick.onEnd = (vec3) =>
        {
            SendCommand(RoleCommand.Idle);
        };
        SkillButton.onCommand += (cmd)=> { SendCommand(cmd); };
    }
    private void SendCommand(RoleCommand command)
    {
        PBMessage.GM_CommandInfo info=new PBMessage.GM_CommandInfo();
        info.roleid=RoleManager.Hero.RoleID;
        info.Command=(int)command;
        Vector3 pos=this.transform.position;
        info.position=new PBMessage.GM_Vector3();
        info.position.x=pos.x;
        info.position.y=pos.y;
        info.position.z=pos.z;
        Vector3 rot=this.transform.eulerAngles;
        info.rotation=new PBMessage.GM_Vector3();
        info.rotation.x=rot.x;
        info.rotation.y=rot.y;
        info.rotation.z=rot.z;
        NetworkManager.Send((int)GameMessage.GM_CommandRequest,info);
        //mRoleController.ExcuteCommand(command);
    }
    // Update is called once per frame
    void Update ()
    {
        if (mRoleController==null)
        {
            return;
        }
        if (UIJoystick.pIsDragging)
        {
            if (mRoleController.pCurMoiton.motionType==RoleMotionType.Idle)
            {
                mRoleController.Turn(UIJoystick.curDir);
                SendCommand(RoleCommand.Run);
            }
            //mRoleController.ExcuteCommand(RoleCommand.Run);
        }
        //控制主角的技能和普攻-----------------------------------------------
        if (Input.GetKeyDown(KeyCode.Q))
        {
            //释放Q技能
            mRoleController.ExcuteCommand(RoleCommand.Skill1);
        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            //释放W技能
            mRoleController.ExcuteCommand(RoleCommand.Skill2);
           
        }
        if (Input.GetKeyDown(KeyCode.E))
        {
            //释放E技能
            mRoleController.ExcuteCommand(RoleCommand.Skill3);
        }
        if (Input.GetKeyDown(KeyCode.R))
        {
            //释放R技能
            mRoleController.ExcuteCommand(RoleCommand.Skill4);
        }
        if (Input.GetKeyDown(KeyCode.A))
        {
            //释放普攻(四种普攻连接)
            mRoleController.ExcuteCommand(RoleCommand.Attack);
        }

        //控制主角的移动和转向------------------------------------------------
        if (Input.GetKey(KeyCode.UpArrow))
        {
            //控制主角向前跑
            mRoleController.ExcuteCommand(RoleCommand.Run);
        }
        if (Input.GetKeyUp(KeyCode.UpArrow))
        {
            //控制主角停止
            mRoleController.ExcuteCommand(RoleCommand.Idle);
        }
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            //控制主角向前跑
            mRoleController.transform.forward = -mRoleController.transform.forward;
            mRoleController.ExcuteCommand(RoleCommand.Run);
        }
        if (Input.GetKeyUp(KeyCode.DownArrow))
        {
            //控制主角停止
            mRoleController.ExcuteCommand(RoleCommand.Idle);
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            //控制主角向左转向
            Quaternion quaternion = this.transform.rotation * Quaternion.AngleAxis(-90 * Time.deltaTime, Vector3.up);
            mRoleController.Turn(quaternion);

            // mRoleController.Turn(Vector3.left);
            //transform.Rotate(Vector3.up, -100f * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            //控制主角向右转向
            Quaternion quaternion = this.transform.rotation * Quaternion.AngleAxis(90 * Time.deltaTime, Vector3.up);
            mRoleController.Turn(quaternion);

            //mRoleController.Turn(Vector3.right);
            //transform.Rotate(Vector3.up, 100f * Time.deltaTime);
        }

        //演示角色被攻击的动作---------------------------------------------------
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            //释放Q技能
            mRoleController.ExcuteCommand(RoleCommand.BeAttack);

        }
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            //释放W技能
            mRoleController.ExcuteCommand(RoleCommand.BeatBack);

        }
        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            //释放E技能
            mRoleController.ExcuteCommand(RoleCommand.BeatWall);
        }
        if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            //释放R技能
            mRoleController.ExcuteCommand(RoleCommand.BeatFloat);
        }
    }
}
