﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.SceneManagement;
using Core;
namespace RPG
{
    public class OverScene : State
    {
        public OverScene() : base(SceneType.Over.ToString())
        {
        }
        public override void OnStart()
        {
            WindowManager.GetManager().OpenWindow("ui_Over");
            SceneManager.LoadScene("Over");
            base.OnStart();
        }
        public override void OnEnd()
        {
            WindowManager.GetManager().CloseWindow("ui_Over");
            RoleManager.Clear();
            base.OnEnd();
        }

    }

}

