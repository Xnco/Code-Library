﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Core;
namespace RPG
{
    public enum SceneType
    {
        Login,
        Game,
        Over,
    }
    public class LoginScene:State
    {
        public static string HeroName;
        public static int HeroID;
        public static int HeroRoleID;

        public LoginScene():base(SceneType.Login.ToString())
        {
        }
        public override void OnStart()
        {
            RegisterNetEvent();
            ConnectServer();
            WindowManager.GetManager().OpenWindow("ui_Login");
            SceneManager.LoadScene("Login");
            base.OnStart();
        }
        void RegisterNetEvent()
        {
            NetworkManager.Register((int)GameMessage.GM_LoginAccountReturn,OnLoginReturn);
            NetworkManager.Register((int)GameMessage.GM_JoinGameReturn,OnJoinGameReturn);
        }
        void UnRegisterNetEvent()
        {
            NetworkManager.UnRegister((int)GameMessage.GM_LoginAccountReturn,OnLoginReturn);
            NetworkManager.UnRegister((int)GameMessage.GM_JoinGameReturn,OnJoinGameReturn);
        }
        void ConnectServer()
        {
            
            NetworkManager.Close();
            //NetworkManager.Connect(1,"127.0.0.1", 5000);
            //NetworkManager.Connect(1,"192.168.1.121", 5000);
            NetworkManager.Connect(1,"192.168.2.12", 5000);
        }
        private void OnLoginReturn(NetPacket pack)
        {
            PBMessage.GM_AccountReturn data=NetPacket.Deserializetion<PBMessage.GM_AccountReturn>(pack.Buffers);
            if (data!=null)
            {
                if (data.m_Result==1)
                {
                    Debug.Log("登陆成功！角色ID:"+data.m_AccountID);
                    PBMessage.GM_JoinGameRequest info=new PBMessage.GM_JoinGameRequest();
                    info.heroID=1;
                    NetworkManager.Send((int)GameMessage.GM_JoinGameRequest,info);
                }
            }
        }
        private void OnJoinGameReturn(NetPacket pack)
        {
            PBMessage.GM_JoinGameReturn data=NetPacket.Deserializetion<PBMessage.GM_JoinGameReturn>(pack.Buffers);
            if (data!=null)
            {
                if (data.result==1)
                {
                    HeroName=data.name;
                    HeroID=data.heroid;
                    HeroRoleID=data.roleid;
                    Game.Goto(RPG.SceneType.Game);
                }
            }
        }
        public override void OnEnd()
        {
            //WindowManager.GetManager().CloseWindow("ui_Login");
            UnRegisterNetEvent();
            base.OnEnd();
        }
    }
}

