﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Core;
namespace RPG
{
    public class GameScene : State
    {
        Camera mainCamera;
        public GameScene() : base(SceneType.Game.ToString())
        {
        }
        public override void OnStart()
        {
            
            RegisterNetworkEvent();

            UILoading uiLoading;
            WindowManager.GetManager().OpenDialog("UILoad", (uiObj) =>
             {
                 WindowManager.GetManager().CloseWindow("ui_Login");

                 LoadMainUI();//加载主界面UI
                 uiLoading = uiObj.GetComponent<UILoading>();

                 uiLoading.OnFinish += () =>
                 {
                    WindowManager.GetManager().CloseDialog("UILoad");//关闭加载界面.
                 };

                 LoadSceneManager.Load("City", uiLoading);
             });
            //WindowManager.GetManager().OpenWindow("ui_Main");
            //SceneManager.LoadScene("City");
            //CreateHero();
            //CreateEnemy();
            base.OnStart();
        }
        private void RegisterNetworkEvent()
        {
            //NetworkManager.Register((int)GameMessage.GM_JoinGameReturn, OnCreateHero);
            NetworkManager.Register((int)GameMessage.GM_CommandReturn, OnReceiveRoleAction);
            NetworkManager.Register((int)GameMessage.GM_OtherPlayerJoin, OnRoleEnter);
            NetworkManager.Register((int)GameMessage.GM_PlayerLeaveNotify,OnRoleLeave);
        }
        private void UnRegisterNetworkEvent()
        {
            //NetworkManager.UnRegister((int)GameMessage.GM_JoinGameReturn, OnCreateHero);
            NetworkManager.UnRegister((int)GameMessage.GM_CommandReturn, OnReceiveRoleAction);
            NetworkManager.UnRegister((int)GameMessage.GM_OtherPlayerJoin, OnRoleEnter);
            NetworkManager.UnRegister((int)GameMessage.GM_PlayerLeaveNotify,OnRoleLeave);
        }
        private void OnCreateHero(object obj)
        {
//            NetPacket pack = obj as NetPacket;
//            if (pack != null)
//            {
//                Role Hero = RoleManager.CreatRole("RolePerfabs/ZhaoYun");//创建主角
//                Hero.RoleID = pack.RoleID;
//                Hero.gameObject.AddComponent<HeroController>();
//                Hero.Register(RoleEventID.Die, OnHeroDie);//监听主角死亡事件
//                Hero.camp = CampType.Red;
//                Hero.mHp = 1000;
//                RoleManager.Hero = Hero;
//
//                GameObject cameraObj = new GameObject("MainCamera");
//                GameObject.DontDestroyOnLoad(cameraObj);
//                cameraObj.transform.tag = "MainCamera";
//                Camera camera = cameraObj.AddComponent<Camera>();
//                camera.cullingMask=1<<LayerMask.NameToLayer("Default");
//                FollowTarget ft= cameraObj.AddComponent<FollowTarget>();
//                ft.Target = Hero.transform;
//                ft.Height = 8;
//                ft.Distacne = 6;
//                mainCamera=camera;
//            }
        }
        private void OnReceiveRoleAction(NetPacket pack)
        {
            PBMessage.GM_CommandInfo info = NetPacket.Deserializetion<PBMessage.GM_CommandInfo>(pack.Buffers);
            if (info != null)
            {
                RoleCommand cmd = (RoleCommand)info.Command;
                Role role = RoleManager.GetRole(info.roleid);
                if (role!=null)
                {
                    role.transform.position = new Vector3(info.position.x, info.position.y, info.position.z);
                    role.transform.eulerAngles = new Vector3(info.rotation.x, info.rotation.y, info.rotation.z);
                    role.pController.ExcuteCommand(cmd);
                }
                
            }

        }
        private void OnRoleEnter(NetPacket pack)
        {
            PBMessage.GM_NotifyOtherRoles info = NetPacket.Deserializetion<PBMessage.GM_NotifyOtherRoles>(pack.Buffers);
            if (info!=null)
            {
                foreach (var item in info.roles)
                {
                    Role role = RoleManager.CreatRole("RolePerfabs/ZhaoYun");//创建其他玩家
                    role.Name=item.name;
                    role.mHp=1000;
                    role.RoleID = item.roleid;
                    role.transform.position = new Vector3(item.position.x,item.position.y,item.position.z);
                    role.transform.eulerAngles= new Vector3(item.rotation.x,item.rotation.y,item.rotation.z);
                    RoleManager.Notify(RoleEventType.CreatRole, role);//广播创建了一个角色,参数就是这个角色的实例
                }
                
            }
        }
        private void OnRoleLeave(NetPacket pack)
        {
            PBMessage.GM_PlayerInfo info = NetPacket.Deserializetion<PBMessage.GM_PlayerInfo>(pack.Buffers);
            if (info!=null)
            {
                RoleManager.RemoveRole(info.roleid); 
                
            }
        }
        //加载主界面UI
        private void LoadMainUI()
        {
            WindowManager.GetManager().OpenWindow("ui_Main",(uiObj)=> 
            {
                CreateHero();//创建主角
                //CreateEnemy();//创建敌人
            });
        }
        public override void OnEnd()
        {
            UnRegisterNetworkEvent();
            WindowManager.GetManager().CloseWindow("ui_Main");
            RoleManager.ClearAllRole();
            if (mainCamera!=null)
            {
                GameObject.Destroy(mainCamera.gameObject);
                mainCamera=null;
            }
            base.OnEnd();
        }
        private void CreateHero()
        {
            Role Hero = RoleManager.CreatRole("RolePerfabs/ZhaoYun");//创建主角
            Hero.gameObject.AddComponent<HeroController>();
            Hero.Register(RoleEventID.Die, OnHeroDie);//监听主角死亡事件
            Hero.camp = CampType.Red;
            Hero.mHp = 10000;
            Hero.RoleID=LoginScene.HeroRoleID;
            Hero.Name=LoginScene.HeroName;
            RoleManager.Hero = Hero;
            RoleManager.Notify(RoleEventType.CreatRole, Hero);//广播创建了一个角色,参数就是这个角色的实例

            GameObject cameraObj = new GameObject("MainCamera");
            GameObject.DontDestroyOnLoad(cameraObj);
            cameraObj.transform.tag = "MainCamera";
            Camera camera = cameraObj.AddComponent<Camera>();
            camera.cullingMask=1<<LayerMask.NameToLayer("Default");
            FollowTarget ft= cameraObj.AddComponent<FollowTarget>();
            ft.Target = Hero.transform;
            ft.Height = 8;
            ft.Distacne = 6;
            mainCamera=camera;
        }
        private void CreateEnemy()
        {
            //Role role = RoleManager.CreatRole("RolePerfabs/ZhaoYun");//创建主角
            //role.camp = CampType.Blue;
            //return role;
            
            //role.Register(RoleEventID.Die, OnHeroDie);//监听敌人死亡事件
        }
        private void OnHeroDie(object obj)
        {
            Game.Goto(SceneType.Over);//跳转到结束场景
        }
    }

}
