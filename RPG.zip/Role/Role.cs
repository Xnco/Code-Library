﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Core;
//攻击信息
public class AttackInfo
{
    public Role Attacker;//攻击者
    public Role BeAttacker;//被攻击者
    public BeatType BeatType;//被打的类型
    public bool isBaoJi;//是否暴击
}
//角色事件ID
public enum RoleEventID
{
    Attack,
    BeAttack,
    HpChange,
    LeaveScene,
    Die,
}
//阵营
public enum CampType
{
    Blue,
    Red,
}
//角色类
public class Role : MonoBehaviour
{
    public string Name;
    public int RoleID;
    public int mHp;//血量
    private int mMaxHp;
    public int mAttack;//攻击力
    public CampType camp;
    public RoleController pController { get; set; }
    private EventManager<object> mEventManager=new EventManager<object>();
    private bool IsDie=false;
    public bool pIsDie
    {
        get{return IsDie;}
    }
    //敌人
    public Role pEnemy { get; set; }
    
    //注册事件
    public void Register(RoleEventID eventID, EventFun<object> fun)
    {
        mEventManager.RegisterEvent((int)eventID, fun);
    }
    //解注册事件
    public void UnRegister(RoleEventID eventID, EventFun<object> fun)
    {
        mEventManager.UnRegisterEvent((int)eventID, fun);
    }
    //广播事件
    public void Notify(RoleEventID eventID, object obj)
    {
        mEventManager.Notify((int)eventID, obj);
    }
    // Use this for initialization
    void Start ()
    {
        pController = GetComponent<RoleController>();
        mMaxHp=mHp;
    }
    //攻击
    public void Attack(Role beAttacker)
    {
        beAttacker.BeAttack(this);
    }
    //被攻击
    public void BeAttack(Role Attacker)
    {
        this.mHp -= Attacker.mAttack;
        Debug.Log(string.Format("{0}正在被{1}攻击,掉了{2}生命值", this.name, Attacker.name, Attacker.mAttack));
        this.GetComponent<RoleController>().ExcuteCommand(RoleCommand.BeAttack);
    }

    //New攻击
    public void Attack(AttackInfo attakerInfo)
    {
        Notify(RoleEventID.Attack, attakerInfo);
        attakerInfo.BeAttacker.BeAttack(attakerInfo);
    }
    //New被攻击
    public void BeAttack(AttackInfo attakerInfo)
    {
        Notify(RoleEventID.BeAttack, attakerInfo); 
        this.mHp -= attakerInfo.Attacker.mAttack;
        Notify(RoleEventID.HpChange, (float)this.mHp/mMaxHp);
        if (this.mHp<=0&&!IsDie)
        {
            IsDie=true;
            Notify(RoleEventID.Die, this);
            pController.ExcuteCommand(RoleCommand.Die);
        }
        Debug.Log(string.Format("{0}正在被{1}攻击,掉了{2}生命值", this.name, attakerInfo.Attacker.name, attakerInfo.Attacker.mAttack));
        if (attakerInfo.BeatType == BeatType.BeAttack)
        {
            pController.ExcuteCommand(RoleCommand.BeAttack);
        }
        if (attakerInfo.BeatType == BeatType.BeatFloat)
        {
            pController.ExcuteCommand(RoleCommand.BeatFloat);
        }
        if (attakerInfo.BeatType == BeatType.BeatBack)
        {
            pController.ExcuteCommand(RoleCommand.BeatBack);
        }
        if (attakerInfo.BeatType == BeatType.BeatWall)
        {
            pController.ExcuteCommand(RoleCommand.BeatWall);
        }
    }
    

}
