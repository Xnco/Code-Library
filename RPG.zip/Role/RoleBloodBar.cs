﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//血条
public class RoleBloodBar : MonoBehaviour {
    public Role mRole;
    //给血条设置角色
    public void SetRole(Role role)
    {
        this.mRole = role;
        UILabel NameLB=GetComponentInChildren<UILabel>();
        NameLB.text=role.Name;
        this.mRole.Register(RoleEventID.HpChange,OnHpChange);//监听这个角色的血量改变事件
        this.mRole.Register(RoleEventID.Die, OnRoleDie);//玩家死亡
        this.mRole.Register(RoleEventID.LeaveScene, OnRoleDie);//玩家死亡
    }
	// Use this for initialization
	void Start () {
		
	}
    //角色血量改变时,此方法被调用.
    void OnHpChange(object x)
    {
        this.GetComponent<UISlider>().value = (float)x;
    }
    //角色死亡事件
    void OnRoleDie(object x)
    {
        Role role = x as Role;
        Destroy(this.gameObject);
    }
    private void OnDestroy()
    {
        this.mRole.UnRegister(RoleEventID.HpChange, OnHpChange);
        this.mRole.UnRegister(RoleEventID.Die, OnRoleDie);
    }
    // Update is called once per frame
    void LateUpdate ()
    {
        if (mRole != null && UICamera.currentCamera != null&&Camera.main!=null)
        {
            Vector3 screenPos = Camera.main.WorldToScreenPoint(mRole.transform.position + Vector3.up * 2.2f);
            screenPos.z = 0;
            Vector3 nguiPos = UICamera.currentCamera.ScreenToWorldPoint(screenPos);
            this.transform.position = nguiPos;
        }
    }
}
