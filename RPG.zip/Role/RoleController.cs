﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;
using System.Net;
using System;
//动作指令
public enum RoleCommand
{
    Attack,//普攻
    Idle,//站立
    Run,//跑步
    Skill1,//技能1
    Skill2,//技能2
    Skill3,//技能3
    Skill4,//技能4
    BeAttack,//被攻击
    BeatWall,//击到墙上
    BeatBack,//击退
    BeatFloat,//浮空
    Die,//死亡
}
//角色动作监听接口
public interface IRoleMotionListener
{
    void OnMotionStart(RoleMotion motion);
    void OnMotionEnd(RoleMotion motion);
}
//角色控制器
public class RoleController : MonoBehaviour
{
    private RoleMotion CurMotion;//当前的动画状态的实例
    public RoleMotion pCurMoiton
    {
        get { return CurMotion; }
    }
    private IRoleMotionListener RoleMotionListener; //角色动作监听接口
    private void Start()
    {
        RoleMotionListener = GetComponentInChildren<IRoleMotionListener>();//获取SkillManager实例
       
    }
    
    //运行动作指令
    public bool ExcuteCommand(RoleCommand command)
    {
        if (CurMotion!=null)
        {
            if (command == RoleCommand.Run && CurMotion.motionType == RoleMotionType.Run)
            {
                return false;
            }
            return CurMotion.ExcuteCommand(command); //当前状态执行该动作指令
        }
        return false;
    }
    public void Move(Vector3 dir)
    {
        
    }
    //角色转向:Force:强制转向
    public void Turn(Vector3 dir, bool Force = false)
    {
        if (Force || (CurMotion != null && CurMotion.CanTurnDirect()))
        {
            dir.y = 0;
            this.transform.rotation=Quaternion.LookRotation(dir);
        }
    }
    //角色转向:Force:强制转向
    public void Turn(Quaternion rotate,bool Force=false)
    {
        if (Force||(CurMotion != null && CurMotion.CanTurnDirect()))
        {
            this.transform.rotation= rotate;
        }
    }
    //动画状态开始
    public void OnMotionStart(RoleMotion motion)
    {
        CurMotion = motion;//保存当前状态实例
        if (RoleMotionListener!=null)
        {
            RoleMotionListener.OnMotionStart(motion);//通知状态开始//skillmanager.OnMotionStart
        }
    }
    //动画状态结束.
    public void OnMotionEnd(RoleMotion motion)
    {
        if (RoleMotionListener != null)
        {
            RoleMotionListener.OnMotionEnd(motion);//通知状态结束
        }
    }
}
