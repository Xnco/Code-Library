﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Core;

public enum RoleEventType
{
    CreatRole,//创建角色
    RemoveRole,//移除玩家
}
//角色管理器
public class RoleManager 
{
    public static Role Hero;//用于保存主角的实例
    static List<Role> AllRoles;//保存所有的角色
    static EventManager<object> EventManager;//角色事件管理器
    public static List<Role> GetAllRoles()
    {
        return new List<Role>(AllRoles);
    }
    static RoleManager()
    {
        AllRoles = new List<Role>();
        EventManager = new EventManager<object>();
        //临时代码,简单获取场景中所有的角色.
        Role[] roles = GameObject.FindObjectsOfType<Role>();//获取场景中所有的角色
        if (roles!=null)
        {
            //将所有角色加入到集合中
            foreach (var item in roles)
            {
                AddRole(item);
            }
        }
      
    }
    //用于添加角色的方法.
    public static void AddRole(Role role)
    {
        role.Register(RoleEventID.Die,OnRoleDie);
        AllRoles.Add(role);
    }
    public static void ClearAllRole()
    {
        foreach (var item in AllRoles)
        {
            GameObject.Destroy(item.gameObject);
        }
        AllRoles.Clear();
    }
    private static void OnRoleDie(object obj)
    {
        Role role=obj as Role;
        if (role!=null)
        {
            AllRoles.Remove(role);
        }
    }
    //获取某个角色位置一定范围的其他所有角色.
    public static List<Role> GetEnemyRoles(Role role,Vector3 offset,float range)
    {
        List<Role> list=new List<Role>();
        //根据角色的位置和偏移量计算出查找范围的中心点坐标
        Vector3 centerPos = role.transform.position + role.transform.TransformDirection(offset);
        foreach (var item in AllRoles)
        {
            if (item==null|| item.pIsDie||item==role||item.camp==role.camp)
            {
                continue;//查找到自己就跳过
            }
            if (Vector3.Distance(centerPos, item.transform.position)<=range)
            {
                list.Add(item);//将在范围中的玩家添加到集合中.
            }
        }
        return list;
    }
    //获取某个角色位置一定范围的其他所有角色.
    public static List<Role> GetFriendRoles(Role role, Vector3 offset, float range)
    {
        List<Role> list = new List<Role>();
        //根据角色的位置和偏移量计算出查找范围的中心点坐标
        Vector3 centerPos = role.transform.position + role.transform.TransformDirection(offset);
        foreach (var item in AllRoles)
        {
            if (item == role || item.camp != role.camp)
            {
                continue;//查找到自己就跳过
            }
            if (Vector3.Distance(centerPos, item.transform.position) <= range)
            {
                list.Add(item);//将在范围中的玩家添加到集合中.
            }
        }
        return list;
    }
    public static Role GetRole(int roleid)
    {
        foreach (var item in AllRoles)
        {
            if (item!=null&&item.RoleID==roleid)
            {
                return item;
            }
        }
        return null;
    }
    public static void RemoveRole(int roleid)
    {
         foreach (var item in AllRoles)
        {
            if (item!=null&&item.RoleID==roleid)
            {
                item.Notify(RoleEventID.LeaveScene,item);
                AllRoles.Remove(item);
                GameObject.Destroy(item.gameObject);
                break;
            }
        }
       
    }
    //创建角色
    public static Role CreatRole(string path)
    {
        GameObject obj = Resources.Load<GameObject>(path);
        if (obj!=null)
        {
            obj = GameObject.Instantiate(obj);
            GameObject.DontDestroyOnLoad(obj);
            Role role = obj.GetComponent<Role>();
            if (role!=null)
            {
                AddRole(role);

            }
            return role;
        }
        return null;
    }
    
    //注册事件
    public static void Register(RoleEventType eventID, EventFun<object> fun)
    {
        EventManager.RegisterEvent((int)eventID, fun);
    }
    //解注册事件
    public static void UnRegister(RoleEventType eventID, EventFun<object> fun)
    {
        EventManager.UnRegisterEvent((int)eventID, fun);
    }
    //广播事件
    public static void Notify(RoleEventType eventID,object obj)
    {
        EventManager.Notify((int)eventID,obj);
    }
    public static void Clear()
    {
        foreach (var item in AllRoles)
        {
            GameObject.Destroy(item.gameObject);
        }
        AllRoles.Clear();
    }
}
