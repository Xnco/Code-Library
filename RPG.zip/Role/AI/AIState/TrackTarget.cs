﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Core;

//追击目标
public class TrackTarget : AIState
{
    public TrackTarget(Role role) : base(AIStateType.Track, role) { }
    public override void OnUpdate()
    {
        if (pRole.pEnemy != null)
        {
            Vector3 dir = pRole.pEnemy.transform.position - pRole.transform.position;//角色朝向敌人的方向向量
            pRole.pController.Turn(dir);//让角色朝向敌人.
            //距离大于等于2,跑向敌人.
            pRole.pController.ExcuteCommand(RoleCommand.Run);
        }
    }
}