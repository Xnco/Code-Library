﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Core;
//攻击状态
public class AttackTarget : AIState
{
    public RoleCommand[] Commands =
       {
            RoleCommand.Attack,
            RoleCommand.Skill1,
            RoleCommand.Skill2,
            RoleCommand.Skill3,
            RoleCommand.Skill4
        };
    public AttackTarget(Role role) : base(AIStateType.Attack, role) { }
    public override void OnUpdate()
    {
        if (pRole.pEnemy != null)
        {
            Vector3 dir = pRole.pEnemy.transform.position - pRole.transform.position;//角色朝向敌人的方向向量
            pRole.pController.Turn(dir);//让角色朝向敌人.
            int index = Random.Range(0, Commands.Length);
            pRole.pController.ExcuteCommand(Commands[index]);
        }
    }
}

