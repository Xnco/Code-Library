﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//逃跑状态
public class EscapeAIState : AIState
{
    public EscapeAIState(Role role) : base(AIStateType.Escape, role) { }
    public override void OnUpdate()
    {
        if (pRole.pEnemy!=null)
        {
            Vector3 dir = pRole.transform.position - pRole.pEnemy.transform.position;
            pRole.pController.Turn(dir);
            pRole.pController.ExcuteCommand(RoleCommand.Run);

        }
        
    }
}
