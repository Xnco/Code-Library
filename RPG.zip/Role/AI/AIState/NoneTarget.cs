﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Core;

//无目标状态
public class NoneTarget : AIState
{
    public NoneTarget(Role role) : base(AIStateType.None, role) { }
    public override void OnUpdate()
    {
        pRole.pController.ExcuteCommand(RoleCommand.Idle);
    }
}
