﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//距离判断
public class DistanceCondition : AICondition
{
    public enum CompareType
    {
        Less,
        Greater,
    }
    public float Distance;
    public CompareType compare=CompareType.Less;
    //public DistanceCondition(Role role, float distance) : base(role)
    //{
    //    Distance = distance;
    //}
    public override bool OnTrigger()
    {
        if (pRole.pEnemy != null)
        {
            float dis = Vector3.Distance(pRole.transform.position, pRole.pEnemy.transform.position);
            if (compare==CompareType.Less)
            {
                if (dis < Distance)
                {
                    return true;
                }
            }
            else if (compare == CompareType.Greater)
            {
                if (dis >= Distance)
                {
                    return true;
                }
            }
            
        }
        return false;
    }
}
