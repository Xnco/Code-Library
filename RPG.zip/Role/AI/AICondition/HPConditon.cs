﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//血量低于一定条件时.
public class HPConditon : AICondition
{
    public float HP;
    public override bool OnTrigger()
    {
        return pRole.mHp<=HP;
    }
}
