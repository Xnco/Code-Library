﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Core;
//血条管理器
public class RoleBloodBarManager : MonoBehaviour
{
    public GameObject clone;
	// Use this for initialization
	void Awake ()
    {
        //监听角色创建事件
        RoleManager.Register(RoleEventType.CreatRole, OnCreateRole);
        List<Role> list=RoleManager.GetAllRoles();
        foreach(var role in list)
        {
            OnCreateRole(role);
        }
    }
    void OnCreateRole(object x)
    {
        Role role = x as Role;
        //创建血条
        GameObject obj = Instantiate(clone, this.transform);
        RoleBloodBar bloodBar = obj.GetComponent<RoleBloodBar>();
        bloodBar.SetRole(role);
       
        obj.SetActive(true);
    }
    private void OnDestroy()
    {
        RoleManager.UnRegister(RoleEventType.CreatRole, OnCreateRole);
    }
    // Update is called once per frame
    void Update ()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            RoleManager.CreatRole("RolePerfabs/ZhaoYun");
        }
	}
}
