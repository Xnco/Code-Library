﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//多段伤害插件
public class MultipleDamagePlug : SkillPlug
{
    public float Range = 3;//距离主角的范围
    public Vector3 Offset;//相等主角位置的偏移量
    
    public DamageInfo[] TriggerDamage;//产生伤害的所有时间点(0.1,0.3,0.5)
    int index;

    public override void OnStart()
    {
        index = 0;
    }
    public override void OnUpdate()
    {
        if (index>=TriggerDamage.Length)
        {
            return;
        }
        if (pOwner.pController.pCurMoiton.pNormalizedTime>=TriggerDamage[index].TriggerTime)
        {
            List<Role> roles = RoleManager.GetEnemyRoles(pOwner, Offset, Range);
            foreach (var role in roles)
            {
                AttackInfo info = new AttackInfo();
                info.Attacker = pOwner;
                info.BeAttacker = role;
                info.BeatType = TriggerDamage[index].BeatType;
                info.isBaoJi = false;
                role.transform.LookAt(pOwner.transform);
                pOwner.Attack(info);//主角攻击敌人
                //role.pController.ExcuteCommand(TriggerDamage[index].command);
            }
            index++;
        }
    }

}
