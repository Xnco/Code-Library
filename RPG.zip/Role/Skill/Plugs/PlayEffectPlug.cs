﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Core;
//特效插件
public class PlayEffectPlug : SkillPlug
{
    public string EffectPath;//特效路径
    private GameObject EffectObj;//特效物体
    public override void Init()
    {
        base.Init();
        EffectObj = EffectPool.Get(EffectPath);
        EffectPool.Put(EffectPath, EffectObj);
    }

    public override void OnStart()
    {
        EffectObj = EffectPool.Get(EffectPath);
        if (EffectObj!=null)
        {
           
            EffectObj.SetActive(true);
            EffectObj.transform.position = this.transform.position;
            EffectObj.transform.rotation = this.transform.rotation;
           
            Animator animator = EffectObj.GetComponentInChildren<Animator>();
            if (animator)
            {
                animator.Update(0);
            }
            
        }
        
    }
    public override void OnEnd()
    {
        if (EffectObj!=null)
        {
            EffectPool.Put(EffectPath, EffectObj);
            EffectObj = null;
        }
    }
}

