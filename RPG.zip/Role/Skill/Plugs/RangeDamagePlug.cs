﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//伤害场景
public class RangeDamagePlug : SkillPlug
{
    public float Range=3;//距离主角的范围
    public Vector3 Offset;//相等主角位置的偏移量
    [Range(0f,1f)]
    public float TriggerTime;
    private bool IsTrigger;
    public override void OnStart()
    {
        IsTrigger = false;
        base.OnStart();
    }
    public override void OnUpdate()
    {
        if (pOwner.pController.pCurMoiton.pNormalizedTime > TriggerTime&&!IsTrigger)
        {
            IsTrigger = true;
            List<Role> roles = RoleManager.GetEnemyRoles(pOwner, Offset, Range);
            foreach (var role in roles)
            {
                pOwner.Attack(role);//主角攻击敌人
            }
        }
        base.OnUpdate();
    }

}
