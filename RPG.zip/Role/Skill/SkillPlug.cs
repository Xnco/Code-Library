﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//被打类型
public enum BeatType
{
    BeAttack,
    BeatBack,
    BeatWall,
    BeatFloat,
}
[System.Serializable]
public class DamageInfo
{
    [Range(0f, 1f)]
    public float TriggerTime;
    public BeatType BeatType;
}

//技能插件
public class SkillPlug:MonoBehaviour
{
    public Role pOwner { get; set; }//所属的角色
    public virtual void Init(){}
    public virtual void OnStart() { }
    public virtual void OnUpdate() { }
    public virtual void OnEnd() { }
}

