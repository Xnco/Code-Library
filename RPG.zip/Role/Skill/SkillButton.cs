﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

//public delegate void ExcuteCommand(RoleCommand command);
//技能按钮
public class SkillButton : MonoBehaviour
{
    public RoleCommand Command;//要执行的指令枚举
    //public static event ExcuteCommand onCommand;//执行指令的委托
    public static event Action<RoleCommand> onCommand;
    void OnClick()
    {
        if (onCommand!=null)
        {
            onCommand(Command);
        }
    }
}
