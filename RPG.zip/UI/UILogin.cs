﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Core;
public class UILogin : MonoBehaviour {
    public UIInput AccountInput;
    public UIInput PasswordInput;
	// Use this for initialization
	void Start ()
    {
        //OnQuHaoChange(1);
        this.GetComponentInChildren<UIButton>().onClick.Add(new EventDelegate(BtnOpenQu));
	}
    void BtnOpenQu()
    {
        PBMessage.GM_AccountRequest info=new PBMessage.GM_AccountRequest();
        info.m_AccountName=AccountInput.value;
        info.m_Password=PasswordInput.value;
        NetworkManager.Send((int)GameMessage.GM_LoginAccountRequest,info);

    }
    void OnQuHaoChange(int num)
    {
        //刷新区号
        UILabel uILabel = GetComponentInChildren<UILabel>();
        uILabel.text = string.Format("{0}区",num);
    }
}
