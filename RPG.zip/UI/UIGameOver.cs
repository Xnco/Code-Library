﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIGameOver : MonoBehaviour 
{

	// Use this for initialization
	void Start () {
        GetComponentInChildren<UIButton>().onClick.Add(new EventDelegate(OnButtonClick));
	}
	
    private void OnButtonClick()
    {
        Game.Goto(RPG.SceneType.Login);
        //Application.Quit();
    }
}
