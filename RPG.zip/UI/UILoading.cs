﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//加载进度UI
public class UILoading : MonoBehaviour, ILoadSceneProgress
{
    public UISlider Slider;
    public event System.Action OnFinish;
    private float curProgress;//进度
   
    private void Update()
    {
        if (Slider.value < curProgress)
        {
            Slider.value += Time.deltaTime;
            if (Slider.value >= 1)
            {
                if (OnFinish != null)
                {
                    OnFinish();
                }
            }
        }
    }
    private void Awake()
    {
        Slider.value = 0f;
    }
    //更新进度条
    public void OnProgress(float progress)
    {
        curProgress = progress;
        Debug.Log(curProgress);
    }
}
