﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public delegate void VoidOnDrag(Vector3 vec);
    
//摇杆
public class UIJoystick : MonoBehaviour
{
    public static VoidOnDrag onStart;
    public static VoidOnDrag onDrag;
    public static VoidOnDrag onEnd;
    private static bool isDragging;//是否正在拖拽
    public static bool pIsDragging
    {
        get { return isDragging; }
    }
    public Transform BgTran;//背景
    public Transform PointTran;//拖拽的小圆点
    private static Vector2 Vec2=Vector2.zero; //记录的总偏移量
    private static Vector3 startPos;//记录小圆点的起始坐标
    public static Vector3 curDir
    {
        get
        {
            return new Vector3(Vec2.x,0,Vec2.y);
        }
    }
    // Use this for initialization
    void Start ()
    {
        UIEventListener.Get(PointTran.gameObject).onDragStart += OnStartDrag;//添加开始拖拽事件
        UIEventListener.Get(PointTran.gameObject).onDrag += OnDragging;//添加拖拽事件
        UIEventListener.Get(PointTran.gameObject).onDragEnd += OnEndDrag;//添加结束拖拽事件
        startPos = this.PointTran.localPosition;
    }
    //开始拖拽
    void OnStartDrag(GameObject go)
    {
        isDragging = true;
        Vec2 = Vector2.zero;//重置记录的总偏移量
        if (onStart!=null)
        {
            onStart(Vec2);
        }
    }
    //拖拽中
    void OnDragging(GameObject obj,Vector2 detal)
    {
        Vec2 += detal;//记录拖动的总偏移量
        Vector3 targVec2 = Vec2;
        if (targVec2.magnitude>90)//如果总偏移量长度超过90
        {
            targVec2 = targVec2.normalized * 90;//将偏移量长度赋值为90;
        }
        if (onDrag!=null)
        {
            onDrag(Vec2);
        }
        obj.transform.localPosition = startPos+ targVec2;//将偏移量赋值给拖动物体.
    }
    //结束拖拽
    void OnEndDrag(GameObject go)
    {
        isDragging = false;
        go.transform.localPosition = startPos;//将小圆点坐标设置为初始位置
        if (onEnd != null)
        {
            onEnd(Vector3.zero);
        }
    }
	// Update is called once per frame
	void Update ()
    {
		
	}
}
