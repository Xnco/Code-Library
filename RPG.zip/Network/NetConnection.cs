﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
namespace Core
{
    //客户端连接
    public class NetConnection
    {
        public int ConnectionID;//连接ID;
        private Socket clientSocket = null;
        public const int HeadSize = 8;
        public byte[] Head = new byte[HeadSize];
        private List<byte> TempList = new List<byte>();
        private Queue<NetPacket> SendQueque = new Queue<NetPacket>();
        private bool SignRelease=false;
        private object lockobj = new object();
        public event Action<NetPacket> OnReceive;
        public NetConnection(Socket socket)
        {
            this.clientSocket = socket;
        }
        public NetConnection(string ip, int port)
        {
            Socket socket= new Socket(AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.Tcp);
            socket.Connect(ip,port);
            this.clientSocket=socket;
        }
        public void Connect(string ip, int port)
        {
            Socket socket= new Socket(AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.Tcp);
            socket.Connect(ip,port);
            this.clientSocket=socket;
        }
        //开始接收数据
        public void StartReceive()
        {
            if (SignRelease)
            {
                return;
            }
            try
            {
                clientSocket.BeginReceive(this.Head, 0, NetConnection.HeadSize, SocketFlags.None, OnReceiveMessage, this);
            }
            catch(Exception exp)
            {
                Console.WriteLine("StartReceive:"+ exp.Message);
            }
            
        }
        //接收到某个客户端的消息时;
        private void OnReceiveMessage(IAsyncResult ar)
        {
            if (SignRelease)
            {
                return;
            }
            lock (lockobj)
            {
                try
                {
                    int size = clientSocket.EndReceive(ar);
                    if (size == NetConnection.HeadSize)
                    {
                        //获取数据包的长度
                        int messageSize = BitConverter.ToInt32(Head, 0);
                        int messageID = BitConverter.ToInt32(Head, 4);
                        if (messageSize > 0)
                        {
                            int revSize = 0;//记录接收的数据大小
                            NetPacket netPack = new NetPacket(messageID, messageSize);
                            while (revSize != messageSize)
                            {
                                revSize += clientSocket.Receive(netPack.Buffers, revSize, messageSize - revSize, SocketFlags.None);//循环接收网络数据
                            }

                            if (OnReceive != null)
                            {
                                netPack.NetConnection = this;
                                OnReceive(netPack);
                            }
                            NetworkManager.Notify(netPack);
                        }
                        StartReceive();
                    }
                    else
                    {
                        Console.WriteLine("接收到的数据长度为零");
                        Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("OnReceive:" + ex.Message);
                    Close();
                }
            }
        }
        //发送消息
        public void Send<T>(int messageID, T data) where T:class,ProtoBuf.IExtensible
        {
            if (SignRelease)
            {
                Console.WriteLine("发送失败:正在关闭这个连接!NetConnection.cs");
                return;
            }
            lock (lockobj)
            {
                try
                {
                    byte[] bytes = NetPacket.Serializetion<T>(data);
                    int size = bytes.Length;
                    byte[] msgsize = BitConverter.GetBytes(size);
                    byte[] msgID = BitConverter.GetBytes(messageID);
                    TempList.Clear();
                    TempList.AddRange(msgsize);
                    TempList.AddRange(msgID);
                    TempList.AddRange(bytes);
                    if (clientSocket != null)
                    {
                        clientSocket.Send(TempList.ToArray());
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine("SendNetPacket(Line:62):" + ex.Message);
                    Close();
                }
            }
        }
        //关闭连接
        public void Close()
        {
            SignRelease = true;
            try
            {
                if (clientSocket != null)
                {
                    if (clientSocket.Connected)
                    {
                        clientSocket.Shutdown(SocketShutdown.Both);
                    }
                    clientSocket.Close();
                    clientSocket = null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Close():" + ex.Message);
            }

        }
    }
}
