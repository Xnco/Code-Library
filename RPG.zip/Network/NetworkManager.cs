﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;
using System.Net;
using System;
using Core;

//网络管理器
public class NetworkManager : MonoBehaviour
{
    private static Dictionary<int,NetConnection> AllConnections=new Dictionary<int, NetConnection>();
    private static EventManager<NetPacket> NetworkEvent=new EventManager<NetPacket>();
    private static Queue<NetPacket> MessageQueue=new Queue<NetPacket>();
    private static NetworkManager Instance;
    static NetworkManager()
    {
        GameObject obj = new GameObject("NetworkManager");
        Instance= obj.AddComponent<NetworkManager>();
        GameObject.DontDestroyOnLoad(obj);
    }
    public static void Connect(int type,string ip, int port)
    {
        NetConnection connection;
        if (!AllConnections.TryGetValue(type,out connection))
        {
            connection=new NetConnection(ip,port);
            AllConnections.Add(type,connection);
        }
        connection.StartReceive();
    }
    public static void Send<T>(int messageID,T data=null) where T:class,ProtoBuf.IExtensible
    {
        NetConnection connection;
        if (AllConnections.TryGetValue(1,out connection))
        {
            connection.Send(messageID,data);
        }
    }
   
	// Update is called once per frame
	void Update ()
    {
        if (this!=Instance)
        {
            return;
        }
        while (MessageQueue.Count>0)
        {
            NetPacket pack=MessageQueue.Dequeue();
            NetworkEvent.Notify(pack.MessageID, pack);
        }
	}
    public static  void Close()
    {
       
    }
    public static void Register(int id,EventFun<NetPacket> fun)
    {
        NetworkEvent.RegisterEvent(id, fun);
    }
    public static void UnRegister(int id, EventFun<NetPacket> fun)
    {
        NetworkEvent.UnRegisterEvent(id, fun);
    }
    public static void Notify(NetPacket pack)
    {
        MessageQueue.Enqueue(pack);
        //NetworkEvent.Notify(pack.MessageID, pack);
    }
}
