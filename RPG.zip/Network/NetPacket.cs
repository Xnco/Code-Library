﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using ProtoBuf;
using System.IO;
namespace Core
{
    public class NetPacket
    {
        public int MessageID
        {
            get;set;
        }
        public byte[] Buffers
        {
            get;set;
        }
        public NetConnection NetConnection
        {
            get;set;
        }
        public NetPacket(int messageid, int length)
        {
            this.MessageID = messageid;
            this.Buffers = new byte[length];
        }
        public static byte[] Serializetion<T>(T t) where T:class,IExtensible
        {
            try
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    Serializer.Serialize<T>(ms, t);
                    return ms.ToArray();
                }
            }
            catch
            {
                Console.WriteLine("序列化失败!");
                return null;
            }
                
        }
        public static T Deserializetion<T>(byte[] data) where T:class,IExtensible
        {
            try
            {
                using (MemoryStream ms = new MemoryStream(data))
                {
                    return Serializer.Deserialize<T>(ms);
                }
            }
            catch
            {
                Console.WriteLine("序列化失败!");
                return default(T);
            }
        }
    }
}
