﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//实现对UI界面的打开与关闭.
//UI规范:
//uiRank--根据路径加载的对象
//--Camera//ui的摄像机
//--uiRank--实例化的对象
//窗口管理器;
public class WindowManager
{
    public delegate void OpenWindowCallBack(GameObject window);
    private Dictionary<string, GameObject> OpenWindows= new Dictionary<string, GameObject>();//打开的窗口.
    private GameObject windowRoot;//所有窗口的根节点
    private GameObject dialogRoot;//所有的最上层的界面
    private List<UIPanel> AllWindowPanels=new List<UIPanel>();//保存所有打开的窗口的Panels
    private List<UIPanel> AllDialogPanels = new List<UIPanel>();
    private static WindowManager Instance;//保存唯一实例
    public static WindowManager GetManager()
    {
        if (Instance==null)
        {
            Instance = new WindowManager();
        }
        return Instance;
    }
    private WindowManager()
    {
        //创建UIRoot
        GameObject uiRootObj = new GameObject("UIRoot");
        Object.DontDestroyOnLoad(uiRootObj);
        UIRoot uiRoot= uiRootObj.AddComponent<UIRoot>();
        uiRoot.minimumHeight = 640;
        uiRoot.maximumHeight = 720;
        uiRoot.scalingStyle = UIRoot.Scaling.Flexible;
        
        //创建摄像机
        GameObject cameraObj = new GameObject("Camera");
        Camera camera= cameraObj.AddComponent<Camera>();//添加摄像机组件
        camera.depth = 1;
        camera.clearFlags = CameraClearFlags.Depth;
        camera.orthographic = true;//设置正交摄像机2D
        camera.orthographicSize = 1;
        camera.nearClipPlane = -10f;
        camera.farClipPlane = 10f;
        camera.cullingMask = 1<<LayerMask.NameToLayer("UI");//设置相机渲染的层
        UICamera uiCamera = cameraObj.AddComponent<UICamera>();//添加NGUI的UICamera相机(NGUI的事件系统)
        cameraObj.transform.SetParent(uiRootObj.transform);
        //创建窗口存放的根节点.
        windowRoot = new GameObject("Windows");//创建一个窗口根节点,加载的窗口都放到该物体下.
        windowRoot.transform.SetParent(uiRootObj.transform);//窗口根节点设置到UIRoot下面
        //创建弹框存放的根节点.
        dialogRoot = new GameObject("Dialogs");//创建一个弹框根节点,加载的窗口都放到该物体下.
        dialogRoot.transform.SetParent(uiRootObj.transform);//窗口根节点设置到UIRoot下面
    }
    //打开UI界面
    public void OpenWindow(string path, OpenWindowCallBack fun=null)
    {
        //加载UI
        LoadUI(path, (uiObj) => 
        {
            if (uiObj!=null)
            {
                SetRoot(uiObj.transform, windowRoot.transform);
                UIPanel[] panels = uiObj.GetComponentsInChildren<UIPanel>();

                System.Array.Sort(panels, (x, y) => { return x.depth - y.depth; });
                RemoveWindowPanel(AllWindowPanels, panels);
                AddWindowPanel(AllWindowPanels, panels);
                ResetAllPanelsDepth(AllWindowPanels, 1);
            }
            if (fun!=null)
            {
                fun(uiObj);
            }
        });
      
    }
    //打开UI界面
    public void OpenDialog(string path, OpenWindowCallBack fun=null)
    {
        //加载UI
        LoadUI(path, (uiObj) =>
        {
            if (uiObj!=null)
            {
                SetRoot(uiObj.transform, dialogRoot.transform);
                UIPanel[] panels = uiObj.GetComponentsInChildren<UIPanel>();
                System.Array.Sort(panels, (x, y) => { return x.depth - y.depth; });
                RemoveWindowPanel(AllDialogPanels, panels);
                AddWindowPanel(AllDialogPanels, panels);
                ResetAllPanelsDepth(AllDialogPanels, 100);
            }
            
            if (fun != null)
            {
                fun(uiObj);
            }
        });

    }
    //加载UI界面
    private void LoadUI(string path, OpenWindowCallBack fun)
    {
        GameObject loadObj;
        //判断该路径的窗口没有打开
        if (OpenWindows.TryGetValue(path, out loadObj))
        {
            if (fun != null)
            {
                fun(loadObj);
            }
            return;
        }
        ResourceLoadCallback callback = delegate (UnityEngine.Object obj, object param)
        {
            loadObj = obj as GameObject;//根据path路径加载一个物体
            if (loadObj == null)
            {
                Debug.LogError("找不到该路径的窗口预设:" + path);
                if (fun != null)
                {
                    fun(null);
                }
                return;
            }
            if (loadObj.transform.childCount != 2)
            {
                Debug.LogError("窗口预设不符合规范:" + path);
                if (fun != null)
                {
                    fun(null);
                }
                return;
            }
            Transform uiTran = loadObj.transform.GetChild(1);
            if (uiTran.GetComponent<Camera>() != null)
            {
                uiTran = loadObj.transform.GetChild(0);
            }
            loadObj = GameObject.Instantiate(uiTran.gameObject);
            OpenWindows.Add(path, loadObj);
            NGUITools.SetLayer(loadObj, LayerMask.NameToLayer("UI"));
            if (fun != null)
            {
                fun(loadObj);
            }
        };
        ResourceManager.GetManager().LoadAsset(path, null, typeof(GameObject), callback);
    }
    //设置父级
    private void SetRoot(Transform child, Transform root)
    {
        child.SetParent(root);
        child.localScale = Vector3.one;
        child.localPosition = Vector3.zero;
        child.localEulerAngles = Vector3.zero;
    }
    //关闭窗口
    public void CloseWindow(string path)
    {
        GameObject windowObj;
        if (OpenWindows.TryGetValue(path, out windowObj))
        {
            UIPanel[] panels = windowObj.GetComponentsInChildren<UIPanel>();
            RemoveWindowPanel(AllWindowPanels, panels);//移除该窗口的所有panel
            ResetAllPanelsDepth(AllWindowPanels, 1);//重置所有Panel的深度
            OpenWindows.Remove(path);//从字典中移除这个窗口
            GameObject.Destroy(windowObj);//销毁掉这个窗口
        }
    }
    //关闭窗口
    public void CloseDialog(string path)
    {
        GameObject windowObj;
        if (OpenWindows.TryGetValue(path, out windowObj))
        {
            UIPanel[] panels = windowObj.GetComponentsInChildren<UIPanel>();
            RemoveWindowPanel(AllDialogPanels, panels);//移除该窗口的所有panel
            ResetAllPanelsDepth(AllDialogPanels, 100);//重置所有Panel的深度
            OpenWindows.Remove(path);//从字典中移除这个窗口
            GameObject.Destroy(windowObj);//销毁掉这个窗口
        }
    }
    //移除窗口的panel
    private void RemoveWindowPanel(List<UIPanel> AllPanels,UIPanel[] removePanels)
    {
        if (AllPanels==null||AllPanels.Count==0)
        {
            return;
        }
        //如果是已经打开的窗口,则移除这个窗口的所有panel.
        if (removePanels!=null)
        {
            foreach (var panel in removePanels)
            {
                AllPanels.Remove(panel);
            }
        }
       
    }
    //添加窗口的panel
    private void AddWindowPanel(List<UIPanel> AllPanels, UIPanel[] addPanels)
    {
        if (addPanels!=null)
        {
            foreach (var panel in addPanels)
            {
                AllPanels.Add(panel);
            }
        }
    }
    //重置所有Panel的深度
    private void ResetAllPanelsDepth(List<UIPanel> panels,int startAt=1)
    {
        //设置每一个panel的深度为它在集合中的索引值+1;
        for (int i = 0; i < panels.Count; i++)
        {
            panels[i].depth = i + startAt;
        }
    }
}
